<template>
    <NuxtPage />
</template>